# Load the required libraries
library(png)
library(grid)

# Check if the file exists in your R working directory
file.exists("distribution_of_ratings.png")


# Load and display the distribution of ratings chart
rating_img <- readPNG("distribution_of_ratings.png")
grid::grid.raster(rating_img)

# Save the chart to a new PNG file
png("output_chart.png")
grid.raster(rating_img)
dev.off()



