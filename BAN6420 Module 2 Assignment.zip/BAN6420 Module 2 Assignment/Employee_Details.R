# Load necessary libraries
if (!requireNamespace("zip", quietly = TRUE)) install.packages("zip")
if (!requireNamespace("readr", quietly = TRUE)) install.packages("readr")

library(zip)   # To handle zip files
library(readr) # To read CSV files

# Define the zip file and output directory
zip_file <- "Employee_Profile.zip"
output_dir <- "Employee_Profile_Contents"

# Unzip the file
if (file.exists(zip_file)) {
  unzip(zip_file, exdir = output_dir) # Unzips the file into the output directory
  print(paste("Unzipped contents to:", output_dir))
  
  # List the files in the output directory
  files <- list.files(output_dir, full.names = TRUE)
  print(paste("Files found:", files))
  
  # Read and display the first CSV file (assuming one file)
  if (length(files) > 0) {
    employee_data <- read_csv(files[1])
    print("Employee Details from CSV:")
    print(employee_data)
  } else {
    print("No files found in the extracted folder.")
  }
} else {
  print("Zip file not found. Please make sure 'Employee_Profile.zip' exists.")
}