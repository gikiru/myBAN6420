### `policyholder.py`
class Policyholder:
    def __init__(self, name, policy_id):
        self.name = name
        self.policy_id = policy_id
        self.is_active = True

    def suspend_policy(self):
        self.is_active = False

    def reactivate_policy(self):
        self.is_active = True

    def __str__(self):
        status = "Active" if self.is_active else "Suspended"
        return f"Policyholder: {self.name}, ID: {self.policy_id}, Status: {status}"