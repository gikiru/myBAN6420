### `product.py`
class Product:
    def __init__(self, product_name, product_id, price):
        self.product_name = product_name
        self.product_id = product_id
        self.price = price
        self.is_available = True

    def update_product(self, new_name=None, new_price=None):
        if new_name:
            self.product_name = new_name
        if new_price:
            self.price = new_price

    def suspend_product(self):
        self.is_available = False

    def __str__(self):
        availability = "Available" if self.is_available else "Suspended"
        return f"Product: {self.product_name}, ID: {self.product_id}, Price: {self.price}, Status: {availability}"
