### `main.ipynb`
from policyholder import Policyholder
from product import Product
from payment import Payment

def main():
    # Create products
    product1 = Product("Health Insurance", "P001", 500)
    product2 = Product("Life Insurance", "P002", 1000)

    # Create policyholders
    policyholder1 = Policyholder("John Doe", "PH001")
    policyholder2 = Policyholder("Jane Smith", "PH002")

    # Process payments
    payment1 = Payment(policyholder1, product1, 500)
    payment1.process_payment()

    payment2 = Payment(policyholder2, product2, 1000)
    payment2.process_payment()

    # Display policyholder details
    print(policyholder1)
    print(payment1)

    print(policyholder2)
    print(payment2)

if __name__ == "__main__":
    main()
