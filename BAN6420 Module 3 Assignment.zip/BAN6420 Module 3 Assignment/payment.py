### `payment.py`
class Payment:
    def __init__(self, policyholder, product, amount):
        self.policyholder = policyholder
        self.product = product
        self.amount = amount
        self.is_paid = False

    def process_payment(self):
        self.is_paid = True

    def __str__(self):
        payment_status = "Paid" if self.is_paid else "Unpaid"
        return f"Payment for {self.policyholder.name} - {self.product.product_name}: {self.amount} ({payment_status})"
