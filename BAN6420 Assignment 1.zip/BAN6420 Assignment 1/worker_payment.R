# Step 1: Load necessary library
set.seed(123)  # For reproducibility

# Step 2: Create a data frame of 400 workers dynamically
num_workers <- 400
workers <- data.frame(
  id = 1:num_workers,
  name = paste("Worker", 1:num_workers, sep = "_"),
  gender = sample(c("Male", "Female"), num_workers, replace = TRUE),
  salary = sample(5000:30000, num_workers, replace = TRUE)
)

# Step 3: Generate payment slips with a for loop
for (i in 1:nrow(workers)) {
  tryCatch({
    # Extract worker details
    worker <- workers[i, ]
    worker_id <- worker$id
    name <- worker$name
    gender <- worker$gender
    salary <- worker$salary

    # Assign employee level based on conditions
    if (salary > 10000 & salary < 20000) {
      employee_level <- "A1"
    } else if (salary > 7500 & salary < 30000 & gender == "Female") {
      employee_level <- "A5-F"
    } else {
      employee_level <- "B"
    }

    # Print payment slip (can also be written to a file)
    cat(sprintf(
      "Payment Slip for %s (ID: %d):\n  Gender: %s\n  Salary: $%d\n  Employee Level: %s\n\n",
      name, worker_id, gender, salary, employee_level
    ))

  }, error = function(e) {
    cat(sprintf("Error processing worker ID %d: %s\n", workers$id[i], e$message))
  })
}

cat("All payment slips generated successfully.\n")
